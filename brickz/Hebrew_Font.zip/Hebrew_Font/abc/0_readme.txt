cd /Users/amosjerbi/Downloads/lego/Hebrew_Font/abc && python3 create_font.py

python3 0_create_font.py