cd [drag folder name to terminal] && python3 create_font.py

python3 0_create_font.py