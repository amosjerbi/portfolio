#!/usr/bin/env python3
"""
Convert Hebrew SVG letters to TrueType font (TTF)
"""

import fontforge
import psMat
import xml.etree.ElementTree as ET
from pathlib import Path

# Hebrew Unicode mappings
HEBREW_UNICODE_MAP = {
    'alef': 0x05D0,      # א
    'bet': 0x05D1,       # ב
    'gimel': 0x05D2,     # ג
    'dalet': 0x05D3,     # ד
    'hey': 0x05D4,       # ה
    'vav': 0x05D5,       # ו
    'zayin': 0x05D6,     # ז
    'het': 0x05D7,       # ח
    'tet': 0x05D8,       # ט
    'yud': 0x05D9,       # י
    'kaf_so': 0x05DA,    # ך (final kaf)
    'kaf': 0x05DB,       # כ
    'lamed': 0x05DC,     # ל
    'mem_so': 0x05DD,    # ם (final mem)
    'mem': 0x05DE,       # מ
    'nun_sofit': 0x05DF,    # ן (final nun)
    'nun': 0x05E0,       # נ
    'samech': 0x05E1,    # ס
    'ayin': 0x05E2,      # ע
    'pey_so': 0x05E3,    # ף (final pey)
    'pey': 0x05E4,       # פ
    'zadik_so': 0x05E5,  # ץ (final tzadik)
    'zadik': 0x05E6,     # צ
    'kuf': 0x05E7,       # ק
    'resh': 0x05E8,      # ר
    'shin': 0x05E9,      # ש
    'tav': 0x05EA,       # ת
}

def create_hebrew_font(svg_dir, output_font_path):
    """Create a TrueType font from SVG files"""
    
    svg_dir = Path(svg_dir)
    
    # Create a new font
    font = fontforge.font()
    
    # Set font properties
    font.fontname = "HebrewBrickFont"
    font.familyname = "Hebrew Brick"
    font.fullname = "Hebrew Brick Font"
    font.copyright = "Custom Hebrew Brick Font"
    font.version = "1.0"
    
    # Set font metrics
    font.em = 1000  # Units per em
    font.ascent = 800
    font.descent = 200
    
    # Process each SVG file
    svg_files = list(svg_dir.glob("*.svg"))
    print(f"Found {len(svg_files)} SVG files\n")
    
    imported_count = 0
    
    for svg_file in sorted(svg_files):
        # Get the base name without extension
        base_name = svg_file.stem.lower()
        
        # Skip files that don't match our letter names
        if base_name not in HEBREW_UNICODE_MAP:
            print(f"⚠️  Skipping {svg_file.name} - no Unicode mapping found")
            continue
        
        # Get the Unicode codepoint
        unicode_point = HEBREW_UNICODE_MAP[base_name]
        
        # Read SVG to get viewBox dimensions
        try:
            tree = ET.parse(svg_file)
            root = tree.getroot()
            viewbox = root.get('viewBox', '0 0 164 164')
            viewbox_parts = viewbox.split()
            svg_width = float(viewbox_parts[2])
            svg_height = float(viewbox_parts[3])
        except Exception as e:
            print(f"⚠️  Could not read viewBox from {svg_file.name}, using default 164x164")
            svg_width = 164
            svg_height = 164
        
        try:
            # Create a glyph for this character
            glyph = font.createChar(unicode_point)
            
            # Import the SVG file
            glyph.importOutlines(str(svg_file))
            
            # Use a consistent reference for visual uniformity
            # Normalize to 165 (standard letter size) for consistent appearance
            bbox = glyph.boundingBox()
            if bbox[0] != 0 or bbox[1] != 0 or bbox[2] != 0 or bbox[3] != 0:
                current_width = bbox[2] - bbox[0]
                current_height = bbox[3] - bbox[1]
                
                # Use 165 as reference (most common dimension ~164-165)
                # This ensures visual consistency across all letters
                reference_size = 165
                target_size = 700
                
                scale_factor = target_size / reference_size
                
                # Transform: scale uniformly
                transform_matrix = psMat.scale(scale_factor)
                glyph.transform(transform_matrix)
                
                # Move to proper position (baseline)
                baseline_offset = 100
                glyph.transform(psMat.translate(0, baseline_offset))
                
                # Set the glyph width based on the scaled width
                glyph.width = int(current_width * scale_factor)
                
                print(f"✅ Imported {base_name:15s} → U+{unicode_point:04X} ({chr(unicode_point)}) - SVG: {svg_width}x{svg_height}")
            else:
                glyph.width = 500
                print(f"✅ Imported {base_name:15s} → U+{unicode_point:04X} ({chr(unicode_point)})")
            
            imported_count += 1
            
        except Exception as e:
            print(f"❌ Error importing {svg_file.name}: {e}")
    
    if imported_count == 0:
        print("\n❌ No glyphs were imported!")
        return
    
    print(f"\n📝 Total glyphs imported: {imported_count}")
    
    # Generate the font
    print(f"\n🔨 Generating font: {output_font_path}")
    
    try:
        font.generate(str(output_font_path))
        print(f"✅ Successfully created font: {output_font_path}")
        print(f"\n💡 To install: Double-click the .ttf file or copy to your fonts folder")
    except Exception as e:
        print(f"❌ Error generating font: {e}")

def main():
    """Main function"""
    # Set paths
    svg_dir = Path(__file__).parent
    output_font = Path(__file__).parent / "HebrewBrick.ttf"
    
    if not svg_dir.exists():
        print(f"❌ Error: Directory not found: {svg_dir}")
        return
    
    print("=" * 60)
    print("Hebrew Brick Font Generator")
    print("=" * 60)
    print(f"\nSVG Directory: {svg_dir}")
    print(f"Output Font:   {output_font}\n")
    
    create_hebrew_font(svg_dir, output_font)

if __name__ == "__main__":
    main()

