#!/usr/bin/env python3
"""
Convert Hebrew SVG letters to TrueType font (TTF)
"""

import fontforge
import psMat
import xml.etree.ElementTree as ET
from pathlib import Path

# Hebrew Unicode mappings
HEBREW_UNICODE_MAP = {
    'alef': 0x05D0,      # א
    'bet': 0x05D1,       # ב
    'gimel': 0x05D2,     # ג
    'dalet': 0x05D3,     # ד
    'hey': 0x05D4,       # ה
    'vav': 0x05D5,       # ו
    'zayin': 0x05D6,     # ז
    'het': 0x05D7,       # ח
    'tet': 0x05D8,       # ט
    'yud': 0x05D9,       # י
    'kaf_so': 0x05DA,    # ך (final kaf)
    'kaf': 0x05DB,       # כ
    'lamed': 0x05DC,     # ל
    'mem_so': 0x05DD,    # ם (final mem)
    'mem': 0x05DE,       # מ
    'nun_sofit': 0x05DF,    # ן (final nun)
    'nun': 0x05E0,       # נ
    'samech': 0x05E1,    # ס
    'ayin': 0x05E2,      # ע
    'pey_so': 0x05E3,    # ף (final pey)
    'pey': 0x05E4,       # פ
    'zadik_so': 0x05E5,  # ץ (final tzadik)
    'zadik': 0x05E6,     # צ
    'kuf': 0x05E7,       # ק
    'resh': 0x05E8,      # ר
    'shin': 0x05E9,      # ש
    'tav': 0x05EA,       # ת
}

# Number Unicode mappings (0-9)
NUMBER_UNICODE_MAP = {
    '0': 0x0030,  # 0
    '1': 0x0031,  # 1
    '2': 0x0032,  # 2
    '3': 0x0033,  # 3
    '4': 0x0034,  # 4
    '5': 0x0035,  # 5
    '6': 0x0036,  # 6
    '7': 0x0037,  # 7
    '8': 0x0038,  # 8
    '9': 0x0039,  # 9
}

# English letters Unicode mappings (A-Z, a-z)
ENGLISH_UNICODE_MAP = {
    'a': 0x0061,  # a
    'b': 0x0062,  # b
    'c': 0x0063,  # c
    'd': 0x0064,  # d
    'e': 0x0065,  # e
    'f': 0x0066,  # f
    'g': 0x0067,  # g
    'h': 0x0068,  # h
    'i': 0x0069,  # i
    'j': 0x006A,  # j
    'k': 0x006B,  # k
    'l': 0x006C,  # l
    'm': 0x006D,  # m
    'n': 0x006E,  # n
    'o': 0x006F,  # o
    'p': 0x0070,  # p
    'q': 0x0071,  # q
    'r': 0x0072,  # r
    's': 0x0073,  # s
    't': 0x0074,  # t
    'u': 0x0075,  # u
    'v': 0x0076,  # v
    'w': 0x0077,  # w
    'x': 0x0078,  # x
    'y': 0x0079,  # y
    'z': 0x007A,  # z
    'A': 0x0041,  # A
    'B': 0x0042,  # B
    'C': 0x0043,  # C
    'D': 0x0044,  # D
    'E': 0x0045,  # E
    'F': 0x0046,  # F
    'G': 0x0047,  # G
    'H': 0x0048,  # H
    'I': 0x0049,  # I
    'J': 0x004A,  # J
    'K': 0x004B,  # K
    'L': 0x004C,  # L
    'M': 0x004D,  # M
    'N': 0x004E,  # N
    'O': 0x004F,  # O
    'P': 0x0050,  # P
    'Q': 0x0051,  # Q
    'R': 0x0052,  # R
    'S': 0x0053,  # S
    'T': 0x0054,  # T
    'U': 0x0055,  # U
    'V': 0x0056,  # V
    'W': 0x0057,  # W
    'X': 0x0058,  # X
    'Y': 0x0059,  # Y
    'Z': 0x005A,  # Z
}

# Special characters Unicode mappings
SPECIAL_UNICODE_MAP = {
    '!': 0x0021,  # !
    '@': 0x0040,  # @
    '#': 0x0023,  # #
    '$': 0x0024,  # $
    '%': 0x0025,  # %
    '^': 0x005E,  # ^
    '&': 0x0026,  # &
    '*': 0x002A,  # *
    '(': 0x0028,  # (
    ')': 0x0029,  # )
    '-': 0x002D,  # -
    '+': 0x002B,  # +
    '?': 0x003F,  # ?
    '<': 0x003C,  # <
    '>': 0x003E,  # >
    '\\': 0x005C,  # \
    '/': 0x002F,  # /
    "'": 0x0027,  # '
}

# Combined mapping
UNICODE_MAP = {**HEBREW_UNICODE_MAP, **NUMBER_UNICODE_MAP, **ENGLISH_UNICODE_MAP, **SPECIAL_UNICODE_MAP}

def create_hebrew_font(svg_dir, output_font_path):
    """Create a TrueType font from SVG files"""
    
    svg_dir = Path(svg_dir)
    
    # Create a new font
    font = fontforge.font()
    
    # Set font properties
    font.fontname = "HebrewBrickFont"
    font.familyname = "Hebrew Brick"
    font.fullname = "Hebrew Brick Font"
    font.copyright = "Custom Hebrew Brick Font"
    font.version = "1.0"
    
    # Set font metrics
    font.em = 1000  # Units per em
    font.ascent = 800
    font.descent = 200
    
    # Process each SVG file
    svg_files = list(svg_dir.glob("*.svg"))
    print(f"Found {len(svg_files)} SVG files\n")
    
    imported_count = 0
    
    for svg_file in sorted(svg_files):
        # Get the base name without extension
        base_name = svg_file.stem.lower()
        
        # Skip files that don't match our letter names
        if base_name not in UNICODE_MAP:
            print(f"⚠️  Skipping {svg_file.name} - no Unicode mapping found")
            continue
        
        # Get the Unicode codepoint
        unicode_point = UNICODE_MAP[base_name]
        
        # Read SVG to get viewBox dimensions
        try:
            tree = ET.parse(svg_file)
            root = tree.getroot()
            viewbox = root.get('viewBox', '0 0 164 164')
            viewbox_parts = viewbox.split()
            svg_width = float(viewbox_parts[2])
            svg_height = float(viewbox_parts[3])
        except Exception as e:
            print(f"⚠️  Could not read viewBox from {svg_file.name}, using default 164x164")
            svg_width = 164
            svg_height = 164
        
        try:
            # Create a glyph for this character
            glyph = font.createChar(unicode_point)
            
            # Import the SVG file
            glyph.importOutlines(str(svg_file))
            
            # Use a consistent reference for visual uniformity
            # Normalize to 165 (standard letter size) for consistent appearance
            bbox = glyph.boundingBox()
            if bbox[0] != 0 or bbox[1] != 0 or bbox[2] != 0 or bbox[3] != 0:
                current_width = bbox[2] - bbox[0]
                current_height = bbox[3] - bbox[1]
                
                # Use 165 as reference (most common dimension ~164-165)
                # This ensures visual consistency across all letters
                reference_size = 165
                target_size = 700
                
                scale_factor = target_size / reference_size
                
                # Transform: scale uniformly
                transform_matrix = psMat.scale(scale_factor)
                glyph.transform(transform_matrix)
                
                # Move to proper position (baseline)
                baseline_offset = 100
                glyph.transform(psMat.translate(0, baseline_offset))
                
                # Set the glyph width based on the scaled width
                glyph.width = int(current_width * scale_factor)
                
                print(f"✅ Imported {base_name:15s} → U+{unicode_point:04X} ({chr(unicode_point)}) - SVG: {svg_width}x{svg_height}")
            else:
                glyph.width = 500
                print(f"✅ Imported {base_name:15s} → U+{unicode_point:04X} ({chr(unicode_point)})")
            
            imported_count += 1
            
        except Exception as e:
            print(f"❌ Error importing {svg_file.name}: {e}")
    
    if imported_count == 0:
        print("\n❌ No glyphs were imported!")
        return
    
    print(f"\n📝 Total glyphs imported: {imported_count}")
    
    # Generate the font
    print(f"\n🔨 Generating font: {output_font_path}")
    
    try:
        font.generate(str(output_font_path))
        print(f"✅ Successfully created font: {output_font_path}")
        print(f"\n💡 To install: Double-click the .ttf file or copy to your fonts folder")
    except Exception as e:
        print(f"❌ Error generating font: {e}")

def main():
    """Main function"""
    # Set paths
    svg_dir = Path(__file__).parent
    output_font = Path(__file__).parent / "HebrewBrick.ttf"
    
    if not svg_dir.exists():
        print(f"❌ Error: Directory not found: {svg_dir}")
        return
    
    print("=" * 60)
    print("Hebrew Brick Font Generator (Hebrew, English, Numbers & Symbols)")
    print("=" * 60)
    print(f"\nSVG Directory: {svg_dir}")
    print(f"Output Font:   {output_font}\n")
    
    create_hebrew_font(svg_dir, output_font)

if __name__ == "__main__":
    main()

